import React, { useState, useEffect } from 'react'
import StatusBar   from './components/StatusBar.jsx'
import MapView     from './components/MapView.jsx'
import ImuPanel    from './components/ImuPanel.jsx'
import RoutePanel  from './components/RoutePanel.jsx'
import AnchorModal from './components/AnchorModal.jsx'
import { usePosition } from './hooks/usePosition.js'
import { useRoute }    from './hooks/useRoute.js'

export default function App() {
  const { position, imuData, health, error, anchorPosition } = usePosition()
  const { route, loading, error: routeError, fetchRoute, clearRoute, activeStep, checkStepAdvance } = useRoute()

  const [showAnchor, setShowAnchor] = useState(false)
  const [sidePanel, setSidePanel]   = useState('route')  // 'route' | 'imu'
  const [mapDest, setMapDest]       = useState(null)     // [lat, lon] from map click

  // Show anchor modal if no position after 5s
  useEffect(() => {
    const t = setTimeout(() => {
      if (!position) setShowAnchor(true)
    }, 5000)
    return () => clearTimeout(t)
  }, [position])

  // Advance route steps as we move
  useEffect(() => {
    if (position?.lat) checkStepAdvance(position.lat, position.lon)
  }, [position])

  // Handle map click — set as destination
  function handleMapClick(lat, lon) {
    if (!position) { setShowAnchor(true); return }
    if (window.confirm(`Route to ${lat.toFixed(5)}, ${lon.toFixed(5)}?`)) {
      fetchRoute(position.lat, position.lon, lat, lon)
    }
  }

  const noGps = health && !health.gpsFix

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      {/* Top status bar */}
      <StatusBar health={health} position={position} />

      {/* Main content */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>

        {/* ── Sidebar ── */}
        <div style={{
          width:        300,
          flexShrink:   0,
          display:      'flex',
          flexDirection:'column',
          background:   'var(--bg2)',
          borderRight:  '1px solid var(--border)',
          overflow:     'hidden',
        }}>
          {/* Tab switcher */}
          <div style={{ display: 'flex', borderBottom: '1px solid var(--border)' }}>
            {['route', 'imu'].map(tab => (
              <button
                key={tab}
                onClick={() => setSidePanel(tab)}
                style={{
                  flex:       1,
                  padding:    '8px 0',
                  background: sidePanel === tab ? 'var(--green-faint)' : 'transparent',
                  borderBottom: sidePanel === tab ? '2px solid var(--green)' : '2px solid transparent',
                  color:      sidePanel === tab ? 'var(--green)' : 'var(--text-dim)',
                  border:     'none',
                  fontFamily: 'var(--mono)',
                  fontSize:   10,
                  letterSpacing: 2,
                  cursor:     'pointer',
                  textTransform: 'uppercase',
                }}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Panel content */}
          <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            {sidePanel === 'route' && (
              <RoutePanel
                route={route}
                loading={loading}
                error={routeError}
                activeStep={activeStep}
                currentPosition={position}
                onRequest={fetchRoute}
                onClear={clearRoute}
              />
            )}
            {sidePanel === 'imu' && (
              <ImuPanel imuData={imuData} />
            )}
          </div>

          {/* Anchor button */}
          {noGps && (
            <div style={{ padding: 10, borderTop: '1px solid var(--border)' }}>
              <button
                onClick={() => setShowAnchor(true)}
                style={{
                  width:      '100%',
                  background: 'transparent',
                  border:     '1px solid var(--amber)',
                  color:      'var(--amber)',
                  fontFamily: 'var(--mono)',
                  fontSize:   10,
                  padding:    '6px 0',
                  cursor:     'pointer',
                  borderRadius: 'var(--radius)',
                  letterSpacing: 1,
                }}
              >
                ⚓ SET POSITION ANCHOR
              </button>
            </div>
          )}
        </div>

        {/* ── Map ── */}
        <div style={{ flex: 1, position: 'relative' }}>
          <MapView
            position={position}
            route={route}
            onMapClick={handleMapClick}
          />

          {/* Error overlay */}
          {error && !position && (
            <div style={{
              position:   'absolute',
              bottom:     60,
              left:       '50%',
              transform:  'translateX(-50%)',
              background: 'var(--bg2)',
              border:     '1px solid var(--red)',
              color:      'var(--red)',
              fontFamily: 'var(--mono)',
              fontSize:   11,
              padding:    '8px 14px',
              borderRadius: 'var(--radius)',
              zIndex:     1000,
              whiteSpace: 'nowrap',
            }}>
              ⚠ {error}
            </div>
          )}

          {/* Active turn instruction overlay */}
          {route?.steps?.[activeStep] && (
            <div style={{
              position:   'absolute',
              top:        12,
              left:       '50%',
              transform:  'translateX(-50%)',
              background: 'var(--bg2)',
              border:     '1px solid var(--green)',
              color:      'var(--text)',
              fontFamily: 'var(--sans)',
              fontSize:   14,
              fontWeight: 600,
              padding:    '8px 16px',
              borderRadius: 'var(--radius)',
              zIndex:     1000,
              whiteSpace: 'nowrap',
              boxShadow:  'var(--panel-glow)',
              maxWidth:   'calc(100% - 24px)',
              overflow:   'hidden',
              textOverflow: 'ellipsis',
            }}>
              {route.steps[activeStep].instruction}
            </div>
          )}
        </div>
      </div>

      {/* Anchor modal */}
      {showAnchor && (
        <AnchorModal
          onAnchor={anchorPosition}
          onClose={() => setShowAnchor(false)}
        />
      )}
    </div>
  )
}
