import { useState } from 'react'

export function useRoute() {
  const [route, setRoute]       = useState(null)
  const [loading, setLoading]   = useState(false)
  const [error, setError]       = useState(null)
  const [activeStep, setActiveStep] = useState(0)

  async function fetchRoute(fromLat, fromLon, toLat, toLon) {
    setLoading(true)
    setError(null)
    setActiveStep(0)
    try {
      const res = await fetch('/api/route', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ from: [fromLat, fromLon], to: [toLat, toLon] }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Routing failed')
      setRoute(data)
    } catch (e) {
      setError(e.message)
      setRoute(null)
    } finally {
      setLoading(false)
    }
  }

  function clearRoute() {
    setRoute(null)
    setError(null)
    setActiveStep(0)
  }

  /** Advance to next step if we're close enough to the waypoint */
  function checkStepAdvance(currentLat, currentLon) {
    if (!route || !route.steps || activeStep >= route.steps.length - 1) return
    const step = route.steps[activeStep]
    if (!step.location) return
    const [sLon, sLat] = step.location
    const dist = haversine(currentLat, currentLon, sLat, sLon)
    if (dist < 30) setActiveStep(s => s + 1)  // 30m threshold
  }

  return { route, loading, error, fetchRoute, clearRoute, activeStep, checkStepAdvance }
}

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371000
  const φ1 = lat1 * Math.PI / 180
  const φ2 = lat2 * Math.PI / 180
  const Δφ = (lat2 - lat1) * Math.PI / 180
  const Δλ = (lon2 - lon1) * Math.PI / 180
  const a  = Math.sin(Δφ/2)**2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ/2)**2
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
}
