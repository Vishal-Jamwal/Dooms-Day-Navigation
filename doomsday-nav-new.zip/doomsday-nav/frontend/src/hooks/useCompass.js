/**
 * useCompass
 *
 * Polls /api/heading independently from the position/IMU hooks.
 * This keeps the compass rose responsive at 10 Hz without coupling
 * it to the slower 1 Hz position poll.
 *
 * Returns:
 *   heading     {number|null}  Smoothed heading 0–360°, null until first read
 *   cardinal    {string|null}  e.g. "NNE"
 *   raw         {object|null}  { x, y, z } calibrated mag values
 *   available   {boolean}      false if QMC5883L not detected by backend
 *   calibrating {boolean}      true while hard-iron cal is running
 *   error       {string|null}  Error message if fetch failed
 *
 *   startCal()  POST /api/calibrate/mag/start
 *   stopCal()   POST /api/calibrate/mag/stop  → returns { offset, scale }
 */

import { useState, useEffect, useRef, useCallback } from 'react'

const POLL_INTERVAL = 100   // ms — matches backend magLoop at 10 Hz

export function useCompass() {
  const [heading,     setHeading]     = useState(null)
  const [cardinal,    setCardinal]    = useState(null)
  const [raw,         setRaw]         = useState(null)
  const [available,   setAvailable]   = useState(false)
  const [calibrating, setCalibrating] = useState(false)
  const [error,       setError]       = useState(null)

  const timerRef    = useRef(null)
  const mountedRef  = useRef(true)

  const fetchHeading = useCallback(async () => {
    try {
      const res  = await fetch('/api/heading')
      const data = await res.json()

      if (!mountedRef.current) return

      if (!res.ok) {
        // 503 = chip not available or no data yet — not a crash
        setAvailable(data.available ?? false)
        setError(data.error ?? 'Heading unavailable')
        return
      }

      setHeading(data.heading)
      setCardinal(data.cardinal)
      setRaw(data.raw ?? null)
      setAvailable(true)
      setCalibrating(data.calibrating ?? false)
      setError(null)
    } catch (e) {
      if (!mountedRef.current) return
      setError('Backend unreachable')
    }
  }, [])

  useEffect(() => {
    mountedRef.current = true
    fetchHeading()
    timerRef.current = setInterval(fetchHeading, POLL_INTERVAL)
    return () => {
      mountedRef.current = false
      clearInterval(timerRef.current)
    }
  }, [fetchHeading])

  async function startCal() {
    const res = await fetch('/api/calibrate/mag/start', { method: 'POST' })
    if (res.ok) setCalibrating(true)
    return res.ok
  }

  async function stopCal() {
    const res  = await fetch('/api/calibrate/mag/stop', { method: 'POST' })
    const data = await res.json()
    if (res.ok) setCalibrating(false)
    return res.ok ? data : null
  }

  return { heading, cardinal, raw, available, calibrating, error, startCal, stopCal }
}
