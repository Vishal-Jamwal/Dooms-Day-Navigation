import { useState, useEffect, useRef } from 'react'

const POLL_INTERVAL = 1000  // ms

export function usePosition() {
  const [position, setPosition] = useState(null)
  const [imuData,  setImuData]  = useState(null)
  const [health,   setHealth]   = useState(null)
  const [error,    setError]    = useState(null)
  const timerRef = useRef(null)

  async function fetchAll() {
    try {
      // Fetch position, health and IMU in parallel.
      // /api/imu always has full pitch/roll/yaw — /api/position only has a
      // stripped imu sub-object which was missing compassHeading in DR mode.
      const [posRes, healthRes, imuRes] = await Promise.all([
        fetch('/api/position'),
        fetch('/api/health'),
        fetch('/api/imu'),
      ])

      if (posRes.ok) {
        setPosition(await posRes.json())
        setError(null)
      } else {
        const err = await posRes.json().catch(() => ({}))
        setError(err.error || 'Position unavailable')
      }

      if (healthRes.ok) {
        setHealth(await healthRes.json())
      }

      // IMU may be 503 if hardware not connected — that's fine, just leave null
      if (imuRes.ok) {
        setImuData(await imuRes.json())
      }

    } catch (e) {
      setError('Cannot reach backend — is it running?')
    }
  }

  useEffect(() => {
    fetchAll()
    timerRef.current = setInterval(fetchAll, POLL_INTERVAL)
    return () => clearInterval(timerRef.current)
  }, [])

  async function anchorPosition(lat, lon) {
    await fetch('/api/anchor', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ lat, lon, heading: 0 }),
    })
    await fetchAll()
  }

  return { position, imuData, health, error, anchorPosition, refresh: fetchAll }
}
