import React, { useState } from 'react'

const ICONS = {
  turn:       '↱',
  'turn left': '↰',
  arrive:     '⬛',
  depart:     '▶',
  roundabout: '↻',
  merge:      '↗',
  default:    '→',
}

function stepIcon(type, modifier) {
  if (type === 'arrive') return '⬛'
  if (type === 'depart') return '▶'
  if (modifier?.includes('left'))  return '↰'
  if (modifier?.includes('right')) return '↱'
  if (type === 'roundabout') return '↻'
  return '→'
}

function fmtDist(m) {
  if (m == null) return ''
  if (m >= 1000) return `${(m / 1000).toFixed(1)} km`
  return `${Math.round(m)} m`
}

function fmtTime(s) {
  if (s == null) return ''
  const m = Math.round(s / 60)
  if (m < 60) return `${m} min`
  return `${Math.floor(m / 60)}h ${m % 60}m`
}

export default function RoutePanel({ route, loading, error, activeStep, onRequest, onClear, currentPosition }) {
  const [dest, setDest]   = useState('')
  const [destLL, setDestLL] = useState(null)
  const [geoError, setGeoError] = useState(null)
  const [geocoding, setGeocoding] = useState(false)

  async function geocode() {
    if (!dest.trim()) return
    setGeocoding(true)
    setGeoError(null)
    try {
      const res  = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(dest)}&format=json&limit=1`)
      const data = await res.json()
      if (!data.length) throw new Error('Location not found')
      const ll = [parseFloat(data[0].lat), parseFloat(data[0].lon)]
      setDestLL(ll)
      return ll
    } catch (e) {
      setGeoError(e.message)
      return null
    } finally {
      setGeocoding(false)
    }
  }

  async function handleRoute() {
    if (!currentPosition) { setGeoError('No current position available'); return }
    let ll = destLL
    if (!ll) ll = await geocode()
    if (!ll) return
    onRequest(currentPosition.lat, currentPosition.lon, ll[0], ll[1])
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Search bar */}
      <div style={{ padding: '10px 12px', borderBottom: '1px solid var(--border)' }}>
        <div style={{
          fontFamily: 'var(--sans)', fontWeight: 700, fontSize: 12,
          letterSpacing: 2, color: 'var(--green)', marginBottom: 8
        }}>NAVIGATE TO</div>

        <div style={{ display: 'flex', gap: 6 }}>
          <input
            value={dest}
            onChange={e => { setDest(e.target.value); setDestLL(null) }}
            onKeyDown={e => e.key === 'Enter' && handleRoute()}
            placeholder="Search destination..."
            style={{
              flex:       1,
              background: 'var(--bg)',
              border:     '1px solid var(--border)',
              color:      'var(--text)',
              fontFamily: 'var(--mono)',
              fontSize:   11,
              padding:    '5px 8px',
              borderRadius: 'var(--radius)',
              outline:    'none',
            }}
          />
          <Btn onClick={handleRoute} disabled={loading || geocoding} accent>
            {loading || geocoding ? '…' : 'GO'}
          </Btn>
          {route && <Btn onClick={onClear}>✕</Btn>}
        </div>

        {geoError && <div style={{ color: 'var(--red)', fontFamily: 'var(--mono)', fontSize: 10, marginTop: 4 }}>{geoError}</div>}
        {error    && <div style={{ color: 'var(--red)', fontFamily: 'var(--mono)', fontSize: 10, marginTop: 4 }}>{error}</div>}
      </div>

      {/* Route summary */}
      {route && (
        <div style={{
          padding:    '8px 12px',
          background: 'var(--green-faint)',
          borderBottom: '1px solid var(--border)',
          fontFamily: 'var(--mono)',
          fontSize:   11,
          display:    'flex',
          gap:        16,
        }}>
          <span style={{ color: 'var(--green)' }}>◈ {fmtDist(route.distance)}</span>
          <span style={{ color: 'var(--text-dim)' }}>⏱ {fmtTime(route.duration)}</span>
          {route.source === 'fallback_direct' && (
            <span style={{ color: 'var(--amber)' }}>⚠ DIRECT LINE</span>
          )}
        </div>
      )}

      {/* Steps list */}
      {route?.steps && (
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {route.steps.map((step, i) => (
            <div
              key={i}
              style={{
                display:       'flex',
                alignItems:    'flex-start',
                gap:           10,
                padding:       '8px 12px',
                borderBottom:  '1px solid var(--border)',
                background:    i === activeStep ? 'var(--green-faint)' : 'transparent',
                borderLeft:    i === activeStep ? '2px solid var(--green)' : '2px solid transparent',
              }}
            >
              <span style={{
                fontSize: 16,
                color:    i === activeStep ? 'var(--green)' : 'var(--text-dim)',
                minWidth: 20,
                marginTop: 1,
              }}>
                {stepIcon(step.type, step.modifier)}
              </span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{
                  fontFamily: 'var(--sans)',
                  fontSize:   12,
                  color:      i === activeStep ? 'var(--text)' : 'var(--text-dim)',
                  lineHeight: 1.3,
                }}>
                  {step.instruction}
                </div>
                {step.distance > 0 && (
                  <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text-dim)', marginTop: 2 }}>
                    {fmtDist(step.distance)}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {!route && !loading && (
        <div style={{
          flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--text-dim)', fontFamily: 'var(--mono)', fontSize: 11, textAlign: 'center',
          padding: 20, lineHeight: 2,
        }}>
          Enter a destination above<br />or click on the map to set one
        </div>
      )}
    </div>
  )
}

function Btn({ children, onClick, disabled, accent }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      background:   accent ? 'var(--green)' : 'var(--bg3)',
      color:        accent ? 'var(--bg)' : 'var(--text-dim)',
      border:       `1px solid ${accent ? 'var(--green)' : 'var(--border)'}`,
      fontFamily:   'var(--mono)',
      fontWeight:   700,
      fontSize:     11,
      padding:      '5px 10px',
      cursor:       disabled ? 'wait' : 'pointer',
      borderRadius: 'var(--radius)',
      flexShrink:   0,
      opacity:      disabled ? 0.6 : 1,
    }}>
      {children}
    </button>
  )
}
