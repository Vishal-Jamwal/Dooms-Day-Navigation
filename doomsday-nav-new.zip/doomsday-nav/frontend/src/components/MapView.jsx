import React, { useEffect, useRef } from 'react'
import L from 'leaflet'

// Fix Leaflet default marker icons (broken in Vite builds)
delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconUrl:      'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl:'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl:    'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
})

// Custom position icon (green pulsing dot)
const posIcon = L.divIcon({
  className: '',
  html: `<div style="
    width:16px; height:16px;
    background:var(--green,#00ff88);
    border-radius:50%;
    border:2px solid #0a0c0f;
    box-shadow:0 0 8px rgba(0,255,136,0.8), 0 0 0 0 rgba(0,255,136,0.4);
    animation:pulse 1.5s infinite;
  "></div>
  <style>
    @keyframes pulse {
      0%   { box-shadow:0 0 8px rgba(0,255,136,0.8), 0 0 0 0 rgba(0,255,136,0.4); }
      70%  { box-shadow:0 0 8px rgba(0,255,136,0.8), 0 0 0 12px rgba(0,255,136,0); }
      100% { box-shadow:0 0 8px rgba(0,255,136,0.8), 0 0 0 0 rgba(0,255,136,0); }
    }
  </style>`,
  iconSize:   [16, 16],
  iconAnchor: [8, 8],
})

const destIcon = L.divIcon({
  className: '',
  html: `<div style="
    width:14px; height:14px;
    background:var(--red,#ff3b3b);
    border-radius:50%;
    border:2px solid #0a0c0f;
    box-shadow:0 0 8px rgba(255,59,59,0.8);
  "></div>`,
  iconSize:   [14, 14],
  iconAnchor: [7, 7],
})

export default function MapView({ position, route, onMapClick }) {
  const containerRef = useRef(null)
  const mapRef       = useRef(null)
  const posMarkerRef = useRef(null)
  const destMarkerRef= useRef(null)
  const routeLayerRef= useRef(null)
  const followRef    = useRef(true)

  // Init map once
  useEffect(() => {
    if (mapRef.current) return
    const map = L.map(containerRef.current, {
      center:    [20, 0],
      zoom:      4,
      zoomControl: true,
      attributionControl: true,
    })

    // Dark OSM tile layer
    L.tileLayer(
      'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        attribution: '© <a href="https://www.openstreetmap.org">OSM</a>',
        maxZoom: 19,
        className: 'map-tiles',   // targeted by CSS filter below
      }
    ).addTo(map)

    // Apply dark filter to tiles via CSS
    const style = document.createElement('style')
    style.textContent = `.map-tiles { filter: invert(1) hue-rotate(180deg) brightness(0.85) saturate(0.7); }`
    document.head.appendChild(style)

    // Click handler — pass clicked coords up
    map.on('click', (e) => {
      if (onMapClick) onMapClick(e.latlng.lat, e.latlng.lng)
    })

    // Stop auto-follow on manual pan
    map.on('dragstart', () => { followRef.current = false })

    mapRef.current = map
    return () => { map.remove(); mapRef.current = null }
  }, [])

  // Update position marker
  useEffect(() => {
    const map = mapRef.current
    if (!map || !position?.lat) return

    const latlng = [position.lat, position.lon]

    if (!posMarkerRef.current) {
      posMarkerRef.current = L.marker(latlng, { icon: posIcon, zIndexOffset: 1000 }).addTo(map)
    } else {
      posMarkerRef.current.setLatLng(latlng)
    }

    if (followRef.current) {
      map.setView(latlng, Math.max(map.getZoom(), 15))
    }
  }, [position])

  // Draw route
  useEffect(() => {
    const map = mapRef.current
    if (!map) return

    // Clear old route
    if (routeLayerRef.current) { routeLayerRef.current.remove(); routeLayerRef.current = null }
    if (destMarkerRef.current) { destMarkerRef.current.remove(); destMarkerRef.current = null }

    if (!route?.geometry) return

    // Route line
    const coords = route.geometry.coordinates.map(([lon, lat]) => [lat, lon])
    routeLayerRef.current = L.polyline(coords, {
      color:  '#00ff88',
      weight: 3,
      opacity: 0.8,
      dashArray: route.source === 'fallback_direct' ? '8,6' : null,
    }).addTo(map)

    // Destination marker
    const last = coords[coords.length - 1]
    destMarkerRef.current = L.marker(last, { icon: destIcon }).addTo(map)

    // Zoom to fit route
    map.fitBounds(routeLayerRef.current.getBounds(), { padding: [40, 40] })
    followRef.current = false
  }, [route])

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>
      <div ref={containerRef} style={{ width: '100%', height: '100%' }} />

      {/* Re-center button */}
      <button
        onClick={() => {
          followRef.current = true
          if (position?.lat && mapRef.current) {
            mapRef.current.setView([position.lat, position.lon], 16)
          }
        }}
        title="Re-center on position"
        style={{
          position:   'absolute',
          bottom:     24,
          right:      12,
          zIndex:     1000,
          background: 'var(--bg2)',
          border:     '1px solid var(--green)',
          color:      'var(--green)',
          fontFamily: 'var(--mono)',
          fontSize:   16,
          width:      34,
          height:     34,
          borderRadius: 'var(--radius)',
          cursor:     'pointer',
          display:    'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >⊕</button>
    </div>
  )
}
