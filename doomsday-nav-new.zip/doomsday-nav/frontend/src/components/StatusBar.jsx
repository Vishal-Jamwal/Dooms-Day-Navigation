import React from 'react'

const dot = (ok) => (
  <span style={{ color: ok ? 'var(--green)' : 'var(--red)', marginRight: 4 }}>●</span>
)

export default function StatusBar({ health, position }) {
  const source = position?.source || '—'
  const sourceLabel = {
    gps:             'GPS',
    dead_reckoning:  'DR',
    fallback_direct: 'DR',
  }[source] || source.toUpperCase()

  const sourceColor = {
    gps:             'var(--green)',
    dead_reckoning:  'var(--amber)',
    fallback_direct: 'var(--red)',
  }[source] || 'var(--text-dim)'

  return (
    <div style={{
      display:        'flex',
      alignItems:     'center',
      gap:            16,
      padding:        '6px 14px',
      background:     'var(--bg2)',
      borderBottom:   '1px solid var(--border)',
      fontFamily:     'var(--mono)',
      fontSize:       11,
      color:          'var(--text-dim)',
      whiteSpace:     'nowrap',
      overflowX:      'auto',
      flexShrink:     0,
    }}>
      {/* Brand */}
      <span style={{ color: 'var(--green)', fontWeight: 700, fontFamily: 'var(--sans)', fontSize: 13, letterSpacing: 2 }}>
        ☠ DOOM NAV
      </span>

      <Divider />

      {/* Hardware status */}
      <span>{dot(health?.imu)} MPU-9250</span>
      <span>{dot(health?.mag)} {health?.magChip ?? 'MAG'}</span>
      <span>{dot(health?.gps)} GPS</span>
      <span>{dot(health?.gpsFix)} FIX</span>

      <Divider />

      {/* Position source */}
      <span>SRC: <span style={{ color: sourceColor }}>{sourceLabel}</span></span>

      {/* Coordinates */}
      {position?.lat != null && (
        <>
          <span>LAT {position.lat.toFixed(5)}</span>
          <span>LON {position.lon.toFixed(5)}</span>
        </>
      )}

      {/* Speed & heading */}
      {position?.speed != null && (
        <span>SPD {(position.speed * 1.852).toFixed(1)} km/h</span>
      )}
      {position?.heading != null && (
        <span>HDG {Math.round(position.heading)}°</span>
      )}

      {/* GPS satellites */}
      {health?.gpsFix && position?.satellites != null && (
        <span>SAT {position.satellites}</span>
      )}

      {/* DR drift warning */}
      {source === 'dead_reckoning' && position?.driftMeters != null && (
        <>
          <Divider />
          <span style={{ color: 'var(--amber)' }}>
            ⚠ DR DRIFT {Math.round(position.driftMeters)}m
          </span>
        </>
      )}

      <div style={{ marginLeft: 'auto' }} />
      <span style={{ opacity: 0.5 }}>{new Date().toLocaleTimeString()}</span>
    </div>
  )
}

function Divider() {
  return <span style={{ color: 'var(--border)', userSelect: 'none' }}>│</span>
}
