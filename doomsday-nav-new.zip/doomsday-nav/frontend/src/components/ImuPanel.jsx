/**
 * ImuPanel
 *
 * Shows MPU-9250 orientation data and QMC5883L compass heading.
 *
 * Compass data comes from useCompass() — its own 100ms poll of /api/heading.
 * IMU data comes from the imuData prop (passed from usePosition via App).
 *
 * Separation of concerns:
 *   - imuData prop: accel/gyro/pitch/roll/yaw  (1 Hz, fine for display)
 *   - useCompass():  heading                    (10 Hz, smooth needle animation)
 */
import React, { useState } from 'react'
import { useCompass } from '../hooks/useCompass.js'

export default function ImuPanel({ imuData }) {
  const {
    heading, cardinal, raw: magRaw,
    available: magOk, calibrating,
    startCal, stopCal,
  } = useCompass()

  const [imuCalBusy, setImuCalBusy] = useState(false)
  const [calDone,    setCalDone]    = useState(false)

  async function handleImuCal() {
    setImuCalBusy(true)
    try { await fetch('/api/calibrate/imu', { method: 'POST' }) }
    finally { setImuCalBusy(false) }
  }

  async function handleMagStop() {
    await stopCal()
    setCalDone(true)
    setTimeout(() => setCalDone(false), 3000)
  }

  return (
    <div style={{ padding: '10px 12px', overflowY: 'auto', height: '100%' }}>

      {/* ── MPU-9250 ─────────────────────────────────────────────── */}
      <SectionHeader
        title="MPU-9250"
        action={
          <Btn onClick={handleImuCal} disabled={imuCalBusy}>
            {imuCalBusy ? 'CAL…' : 'RECAL'}
          </Btn>
        }
      />

      {!imuData ? (
        <Warn>No IMU data · SDA→GPIO2(Pin3) SCL→GPIO3(Pin5)</Warn>
      ) : (
        <>
          <AngleRow label="PITCH" value={imuData.pitch} max={90}  color="var(--green)" />
          <AngleRow label="ROLL"  value={imuData.roll}  max={90}  color="var(--green)" />
          <AngleRow label="YAW"   value={imuData.yaw}   max={360} color="var(--blue)"  />
          <Divider />
          <RawGrid accel={imuData.accel} gyro={imuData.gyro} temp={imuData.temp} />
        </>
      )}

      {/* ── QMC5883L Compass ─────────────────────────────────────── */}
      <Divider style={{ margin: '14px 0' }} />
      <SectionHeader title="QMC5883L" action={null} />

      {!magOk ? (
        <Warn>QMC5883L offline · i2cdetect -y 1 should show 0x0D</Warn>
      ) : heading === null ? (
        <Warn>Waiting for heading data…</Warn>
      ) : (
        <>
          {/* Compass rose — animates at 10 Hz because useCompass polls 100ms */}
          <div style={{ display: 'flex', justifyContent: 'center', margin: '10px 0 6px' }}>
            <CompassRose heading={heading} />
          </div>

          {/* Heading readout */}
          <div style={{
            fontFamily: 'var(--mono)', fontSize: 13, textAlign: 'center',
            color: 'var(--text)', marginBottom: 8, letterSpacing: 1,
          }}>
            {heading.toFixed(1)}°
            <span style={{ color: 'var(--text-dim)', marginLeft: 8, fontSize: 11 }}>
              {cardinal}
            </span>
          </div>

          {/* Raw XYZ readout */}
          {magRaw && (
            <div style={{
              fontFamily: 'var(--mono)', fontSize: 10,
              color: 'var(--text-dim)', textAlign: 'center',
              marginBottom: 8, lineHeight: 1.7,
            }}>
              X {fmtMag(magRaw.x)} &nbsp;
              Y {fmtMag(magRaw.y)} &nbsp;
              Z {fmtMag(magRaw.z)}
            </div>
          )}
        </>
      )}

      {/* ── Magnetometer calibration ─────────────────────────────── */}
      <div style={{ marginTop: 4 }}>
        {!calibrating && !calDone && (
          <Btn onClick={startCal} full accent>START MAG CAL</Btn>
        )}
        {calibrating && (
          <Btn
            onClick={handleMagStop}
            full
            style={{ borderColor: 'var(--amber)', color: 'var(--amber)' }}
          >
            ● RECORDING — tap to finish
          </Btn>
        )}
        {calDone && (
          <div style={{
            fontFamily: 'var(--mono)', fontSize: 10,
            color: 'var(--green)', textAlign: 'center', padding: '4px 0',
          }}>
            ✓ Calibration applied
          </div>
        )}
      </div>
      <div style={{
        fontFamily: 'var(--mono)', fontSize: 9,
        color: 'var(--text-dim)', marginTop: 6, lineHeight: 1.7,
      }}>
        START → rotate device in a slow figure-8 → tap again to finish.
        Fixes hard-iron distortion from nearby metal.
      </div>

    </div>
  )
}

// ── Compass rose SVG ─────────────────────────────────────────────

function CompassRose({ heading }) {
  // The ring stays fixed; only the needle group rotates
  const needleStyle = {
    transform:        `rotate(${heading}deg)`,
    transformOrigin:  '50% 50%',
    transition:       'transform 0.1s linear',
  }

  return (
    <svg width="96" height="96" viewBox="0 0 96 96">
      {/* Tick marks every 30° */}
      {Array.from({ length: 12 }, (_, i) => {
        const a   = (i * 30) * Math.PI / 180
        const len = i % 3 === 0 ? 10 : 5
        const x1  = 48 + Math.sin(a) * (44 - len)
        const y1  = 48 - Math.cos(a) * (44 - len)
        const x2  = 48 + Math.sin(a) * 44
        const y2  = 48 - Math.cos(a) * 44
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
          stroke="var(--border)" strokeWidth={i % 3 === 0 ? 1.5 : 0.8} />
      })}

      {/* Cardinal letters — fixed, outside the needle group */}
      {[['N', 0], ['E', 90], ['S', 180], ['W', 270]].map(([label, angle]) => {
        const a = angle * Math.PI / 180
        return (
          <text
            key={label}
            x={48 + Math.sin(a) * 33}
            y={48 - Math.cos(a) * 33 + 4}
            textAnchor="middle"
            fill={label === 'N' ? 'var(--green)' : 'var(--text-dim)'}
            fontSize="9"
            fontFamily="var(--mono)"
            fontWeight={label === 'N' ? '700' : '400'}
          >
            {label}
          </text>
        )
      })}

      {/* Outer ring */}
      <circle cx="48" cy="48" r="44"
        fill="none" stroke="var(--border)" strokeWidth="1" />

      {/* Rotating needle group */}
      <g style={needleStyle}>
        {/* North point — bright green */}
        <polygon
          points="48,12 44,48 52,48"
          fill="var(--green)"
          opacity="0.95"
        />
        {/* South point — dim */}
        <polygon
          points="48,84 44,48 52,48"
          fill="var(--text-dim)"
          opacity="0.4"
        />
      </g>

      {/* Centre cap */}
      <circle cx="48" cy="48" r="4"
        fill="var(--bg2)" stroke="var(--green)" strokeWidth="1.5" />
    </svg>
  )
}

// ── Small reusable components ────────────────────────────────────

function SectionHeader({ title, action }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between',
      alignItems: 'center', marginBottom: 8,
    }}>
      <span style={{
        fontFamily: 'var(--sans)', fontWeight: 700,
        fontSize: 12, letterSpacing: 2, color: 'var(--green)',
      }}>
        {title}
      </span>
      {action}
    </div>
  )
}

function AngleRow({ label, value, color, max }) {
  const pct = value != null ? Math.min(Math.abs(value) / max, 1) : 0
  return (
    <div style={{ marginBottom: 6 }}>
      <div style={{
        display: 'flex', justifyContent: 'space-between',
        fontFamily: 'var(--mono)', fontSize: 11, marginBottom: 2,
      }}>
        <span style={{ color: 'var(--text-dim)' }}>{label}</span>
        <span style={{ color: 'var(--text)' }}>{value?.toFixed(1) ?? '?'}°</span>
      </div>
      <div style={{ height: 3, background: 'var(--bg)', borderRadius: 2 }}>
        <div style={{
          width: `${pct * 100}%`, height: '100%',
          background: color, borderRadius: 2, transition: 'width 0.15s',
        }} />
      </div>
    </div>
  )
}

function RawGrid({ accel, gyro, temp }) {
  return (
    <div style={{
      fontFamily: 'var(--mono)', fontSize: 10,
      color: 'var(--text-dim)', lineHeight: 1.9,
    }}>
      <div>AX {f(accel?.x)} AY {f(accel?.y)} AZ {f(accel?.z)}<span style={{ fontSize: 9 }}> g</span></div>
      <div>GX {f(gyro?.x)}  GY {f(gyro?.y)}  GZ {f(gyro?.z)}<span style={{ fontSize: 9 }}> °/s</span></div>
      {temp != null && <div style={{ marginTop: 2 }}>TEMP {temp.toFixed(1)}°C</div>}
    </div>
  )
}

function Warn({ children }) {
  return (
    <div style={{
      fontFamily: 'var(--mono)', fontSize: 10,
      color: 'var(--red)', lineHeight: 1.6, marginBottom: 8,
    }}>
      {children}
    </div>
  )
}

function Divider({ style }) {
  return <div style={{ height: 1, background: 'var(--border)', margin: '8px 0', ...style }} />
}

function Btn({ children, onClick, disabled, full, accent, style: extra }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      width:        full ? '100%' : undefined,
      background:   accent ? 'var(--green)' : 'transparent',
      color:        accent ? 'var(--bg)' : 'var(--green)',
      border:       '1px solid var(--border)',
      fontFamily:   'var(--mono)',
      fontWeight:   700,
      fontSize:     9,
      padding:      '4px 8px',
      cursor:       disabled ? 'wait' : 'pointer',
      borderRadius: 'var(--radius)',
      opacity:      disabled ? 0.6 : 1,
      letterSpacing: 1,
      ...extra,
    }}>
      {children}
    </button>
  )
}

// Format IMU float with sign padding
function f(v) {
  if (v == null) return '   — '
  const s = v.toFixed(2)
  return v >= 0 ? ` ${s}` : s
}

// Format magnetometer value (can be large raw integers or small floats)
function fmtMag(v) {
  if (v == null) return '—'
  return v.toFixed(0)
}

function cardinalDir(deg) {
  const dirs = ['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW']
  return dirs[Math.round(deg / 22.5) % 16]
}
