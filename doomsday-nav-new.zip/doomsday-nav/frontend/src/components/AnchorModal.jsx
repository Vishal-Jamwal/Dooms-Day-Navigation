import React, { useState } from 'react'

export default function AnchorModal({ onAnchor, onClose }) {
  const [lat, setLat]     = useState('')
  const [lon, setLon]     = useState('')
  const [query, setQuery] = useState('')
  const [searching, setSearching] = useState(false)
  const [err, setErr]     = useState(null)

  async function geocodeAndAnchor() {
    if (!query.trim()) return
    setSearching(true)
    setErr(null)
    try {
      const res  = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=1`)
      const data = await res.json()
      if (!data.length) throw new Error('Location not found')
      await onAnchor(parseFloat(data[0].lat), parseFloat(data[0].lon))
      onClose()
    } catch (e) {
      setErr(e.message)
    } finally {
      setSearching(false)
    }
  }

  async function manualAnchor() {
    const la = parseFloat(lat), lo = parseFloat(lon)
    if (isNaN(la) || isNaN(lo)) { setErr('Enter valid lat/lon numbers'); return }
    await onAnchor(la, lo)
    onClose()
  }

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999,
    }}>
      <div style={{
        background: 'var(--bg2)',
        border:     '1px solid var(--green)',
        borderRadius: 'var(--radius)',
        padding:    24,
        width:      320,
        boxShadow:  '0 0 40px rgba(0,255,136,0.15)',
      }}>
        <div style={{ fontFamily: 'var(--sans)', fontWeight: 700, fontSize: 14, letterSpacing: 2, color: 'var(--green)', marginBottom: 16 }}>
          ⚓ SET POSITION ANCHOR
        </div>
        <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text-dim)', marginBottom: 16, lineHeight: 1.6 }}>
          No GPS fix. Set your current position manually so dead reckoning can work.
        </div>

        {/* Search by name */}
        <label style={labelStyle}>SEARCH BY NAME</label>
        <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
          <input value={query} onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && geocodeAndAnchor()}
            placeholder="e.g. Mumbai Central" style={inputStyle} />
          <button onClick={geocodeAndAnchor} disabled={searching} style={btnStyle(true)}>
            {searching ? '…' : 'SET'}
          </button>
        </div>

        <div style={{ textAlign: 'center', color: 'var(--text-dim)', fontFamily: 'var(--mono)', fontSize: 10, marginBottom: 12 }}>
          — OR —
        </div>

        {/* Manual coords */}
        <label style={labelStyle}>MANUAL COORDINATES</label>
        <div style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
          <input value={lat} onChange={e => setLat(e.target.value)} placeholder="Latitude" style={inputStyle} />
          <input value={lon} onChange={e => setLon(e.target.value)} placeholder="Longitude" style={inputStyle} />
        </div>
        <button onClick={manualAnchor} style={{ ...btnStyle(true), width: '100%', marginBottom: 12 }}>
          ANCHOR HERE
        </button>

        {err && <div style={{ color: 'var(--red)', fontFamily: 'var(--mono)', fontSize: 10, marginBottom: 8 }}>{err}</div>}

        <button onClick={onClose} style={{ ...btnStyle(false), width: '100%' }}>CANCEL</button>
      </div>
    </div>
  )
}

const labelStyle = {
  display:    'block',
  fontFamily: 'var(--mono)',
  fontSize:   9,
  color:      'var(--text-dim)',
  marginBottom: 4,
  letterSpacing: 1,
}

const inputStyle = {
  flex:       1,
  background: 'var(--bg)',
  border:     '1px solid var(--border)',
  color:      'var(--text)',
  fontFamily: 'var(--mono)',
  fontSize:   11,
  padding:    '5px 8px',
  borderRadius: 'var(--radius)',
  outline:    'none',
  minWidth:   0,
}

const btnStyle = (accent) => ({
  background:   accent ? 'var(--green)' : 'var(--bg3)',
  color:        accent ? 'var(--bg)' : 'var(--text-dim)',
  border:       `1px solid ${accent ? 'var(--green)' : 'var(--border)'}`,
  fontFamily:   'var(--mono)',
  fontWeight:   700,
  fontSize:     11,
  padding:      '5px 10px',
  cursor:       'pointer',
  borderRadius: 'var(--radius)',
  flexShrink:   0,
})
