# 🧭 Doomsday Navigation — Pi Zero 2W Edition

A lightweight offline-capable navigation system designed for the Raspberry Pi Zero 2W with MPU6050 IMU support for dead reckoning when GPS is unavailable.

## Architecture

```
Pi Zero 2W
├── backend/          Node.js Express API (port 3000)
│   ├── MPU6050 I2C reader (dead reckoning)
│   ├── GPS NMEA parser (optional USB GPS)
│   └── OSRM routing (uses public API, falls back to straight-line)
└── frontend/         Vite + React map UI (port 5173)
    ├── Leaflet.js map (OpenStreetMap tiles)
    ├── Live position tracking
    └── Turn-by-turn directions
```

## Hardware Requirements

| Component | Details |
|-----------|---------|
| Pi Zero 2W | 512MB RAM, ARM Cortex-A53 |
| MPU-9250 | 9-axis IMU, I2C address 0x68 |
| HMC5883L | 3-axis magnetometer, I2C address 0x1E (QMC5883L clone at 0x0D also supported) |
| GPS Module | USB or UART (optional, enables precise positioning) |
| Power | 5V 2A micro-USB |
| SD Card | 8GB+ Class 10 |

## Quick Setup

### 1. Flash Pi OS
Flash **Raspberry Pi OS Lite 64-bit** using Raspberry Pi Imager.
Enable SSH and WiFi in the imager settings before flashing.

### 2. Transfer Project
```bash
# From your PC
scp -r doomsday-nav/ pi@<PI_IP>:~/
```

### 3. Run Setup Script
```bash
ssh pi@<PI_IP>
cd ~/doomsday-nav
chmod +x scripts/setup.sh
sudo ./scripts/setup.sh
```

### 4. Wire the sensors

**MPU-9250** (I2C address 0x68):
```
MPU-9250 → Pi Zero 2W
VCC      → Pin 1  (3.3V)
GND      → Pin 6  (GND)
SDA      → Pin 3  (GPIO2)
SCL      → Pin 5  (GPIO3)
AD0      → GND    (keeps address at 0x68)
```

**HMC5883L** (shares the same I2C bus, address 0x1E):
```
HMC5883L → Pi Zero 2W
VCC      → Pin 1  (3.3V)  ← same rail, use 3.3V NOT 5V
GND      → Pin 6  (GND)
SDA      → Pin 3  (GPIO2) ← same as MPU-9250
SCL      → Pin 5  (GPIO3) ← same as MPU-9250
DRDY     → not connected
```

> **Note:** If `i2cdetect -y 1` shows your magnetometer at `0x0D` instead of `0x1E`,
> you have a QMC5883L clone — the driver handles both automatically.

> **Note on MPU-9250 pass-through:** The firmware enables I2C pass-through on the
> MPU-9250 at boot so the HMC5883L appears directly on the Pi's I2C bus.

### 5. Start Services
```bash
sudo systemctl start doomsday-backend
sudo systemctl start doomsday-frontend
```

### 6. Open in Browser
Navigate to `http://<PI_IP>:5173` from any device on the same network.

## Manual Start (without systemd)
```bash
# Terminal 1
cd ~/doomsday-nav/backend && npm start

# Terminal 2
cd ~/doomsday-nav/frontend && npm run dev -- --host
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Hardware status (IMU, MAG, GPS, DR) |
| GET | `/api/imu` | MPU-9250 accel/gyro/orientation |
| GET | `/api/compass` | HMC5883L heading + chip type |
| GET | `/api/position` | Fused position (GPS → dead reckoning) |
| POST | `/api/route` | Route between two points `{from:[lat,lon], to:[lat,lon]}` |
| POST | `/api/calibrate/imu` | Re-zero gyro/accel (keep device still) |
| POST | `/api/calibrate/mag/start` | Begin hard-iron calibration |
| POST | `/api/calibrate/mag/stop` | Finish calibration (rotate device figure-8 first) |
| POST | `/api/anchor` | Seed dead reckoning `{lat, lon}` |

## Troubleshooting

**MPU-9250 not detected:**
```bash
i2cdetect -y 1   # Should show 0x68
```

**HMC5883L not detected:**
```bash
i2cdetect -y 1   # Should show 0x1E (genuine) or 0x0D (QMC5883L clone)
```
If nothing shows, check wiring and that I2C pass-through is enabled (happens automatically at boot).

**Compass heading is wrong / drifting:**
Use the MAG CAL button in the IMU panel. Rotate the device slowly in a figure-8 pattern for ~30 seconds to collect hard-iron calibration data.

**Backend won't start:**
```bash
journalctl -u doomsday-backend -f
```
