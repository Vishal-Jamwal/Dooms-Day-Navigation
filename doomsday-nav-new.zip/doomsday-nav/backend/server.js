/**
 * Doomsday Navigation — Backend Server
 * Pi Zero 2W optimised — MPU-9250 + HMC5883L (or QMC5883L clone)
 *
 * Endpoints:
 *   GET  /api/health               — service + hardware status
 *   GET  /api/imu                  — raw MPU-9250 accel/gyro/orientation
 *   GET  /api/compass              — HMC5883L heading
 *   GET  /api/position             — fused position (GPS > DR)
 *   POST /api/route                — { from: [lat,lon], to: [lat,lon] }
 *   POST /api/calibrate/imu        — re-run gyro/accel zero calibration
 *   POST /api/calibrate/mag/start  — begin hard-iron calibration
 *   POST /api/calibrate/mag/stop   — finish calibration & apply offsets
 *   POST /api/anchor               — force position { lat, lon }
 */

const express       = require('express');
const cors          = require('cors');
const MPU9250       = require('./mpu9250');
const QMC5883L      = require('./magnetometer');   // QMC5883L-only driver
const GPSParser     = require('./gps');
const DeadReckoning = require('./deadReckoning');
const { getRoute }  = require('./routing');

const app  = express();
const PORT = process.env.PORT || 3000;

// Magnetic declination for your location (degrees).
// Mumbai ≈ -0.8°  Find yours: https://www.ngdc.noaa.gov/geomag/calculators/magcalc.shtml
const MAGNETIC_DECLINATION = parseFloat(process.env.DECLINATION || '-0.8');

app.use(cors());
app.use(express.json());

// ──────────────────────────────────────────────────────
// Hardware instances
// ──────────────────────────────────────────────────────

const imu = new MPU9250(1, 0x68);
const mag = new QMC5883L(1, {         // confirmed chip at 0x0D
  smoothingAlpha: 0.2,
  declination:    MAGNETIC_DECLINATION,
});
const gps = new GPSParser(process.env.GPS_PORT || '/dev/ttyUSB0', 9600);
const dr  = new DeadReckoning();

let orientation    = null;
let lastImuData    = null;
let compassHeading = null;
let lastMagData    = null;

async function initHardware() {
  const imuOk = await imu.init();
  if (imuOk) await imu.calibrate(100);

  // MPU-9250 init enables I2C pass-through so HMC5883L is visible on main bus
  const magOk = await mag.init();
  if (!magOk) {
    console.warn('[Server] No magnetometer — heading will use gyro integration (drifts over time)');
  }

  const gpsOk = await gps.init();
  if (!gpsOk) {
    console.log('[Server] No GPS — POST /api/anchor { lat, lon } to seed dead reckoning');
  }

  console.log(`[Server] IMU:${imuOk?'✓':'✗'}  MAG:${magOk?'✓':'✗'}  GPS:${gpsOk?'✓':'✗'}`);
}

// ──────────────────────────────────────────────────────
// Sensor loops
// ──────────────────────────────────────────────────────

async function imuLoop() {
  const result = await imu.getOrientation(compassHeading);
  if (result) { orientation = result; lastImuData = result; }
  setTimeout(imuLoop, 50);   // 20 Hz
}

async function magLoop() {
  if (!mag.available) return;
  const result = await mag.getHeading(
    orientation?.pitch ?? 0,
    orientation?.roll  ?? 0
    // declination is set in the QMC5883L constructor — not a per-call arg
  );
  if (result !== null) {
    compassHeading = result.heading;
    lastMagData = { heading: result.heading, raw: result.cal, timestamp: Date.now() };
  }
  setTimeout(magLoop, 100);  // 10 Hz
}

async function fusionLoop() {
  const gpsPos = gps.getPosition();
  if (gpsPos.fix && gpsPos.lat !== null) {
    dr.anchor(gpsPos.lat, gpsPos.lon, gpsPos.heading ?? compassHeading ?? 0);
  } else if (dr.enabled && orientation) {
    dr.update(orientation, null, compassHeading);
  }
  setTimeout(fusionLoop, 100);
}

// ──────────────────────────────────────────────────────
// API routes
// ──────────────────────────────────────────────────────

app.get('/api/health', (req, res) => {
  res.json({
    status:      'ok',
    imu:         imu.available,
    imuChip:     imu.whoAmI ? `MPU-9250 (WHO_AM_I=0x${imu.whoAmI.toString(16)})` : null,
    mag:         mag.available,
    magChip:     mag.available ? 'QMC5883L' : null,
    gps:         gps.available,
    gpsFix:      gps.getPosition().fix,
    dr:          dr.enabled,
    declination: MAGNETIC_DECLINATION,
    uptime:      Math.round(process.uptime()),
  });
});

app.get('/api/imu', (req, res) => {
  if (!imu.available) {
    return res.status(503).json({
      error: 'MPU-9250 not available',
      hint:  'Check wiring: SDA→GPIO2(Pin3), SCL→GPIO3(Pin5). Run: i2cdetect -y 1',
    });
  }
  if (!lastImuData) return res.status(503).json({ error: 'No IMU data yet' });
  res.json({
    accel:          lastImuData.raw.accel,
    gyro:           lastImuData.raw.gyro,
    temp:           lastImuData.raw.temp,
    pitch:          lastImuData.pitch,
    roll:           lastImuData.roll,
    yaw:            lastImuData.yaw,
    compassHeading, // always present — null if mag not available
    timestamp:      lastImuData.raw.timestamp,
  });
});

// /api/heading — dedicated endpoint the frontend polls for compass data.
// Returns the latest smoothed heading from the QMC5883L.
// This is the canonical endpoint for the compass panel.
app.get('/api/heading', (req, res) => {
  if (!mag.available) {
    return res.status(503).json({
      error:     'QMC5883L not available',
      hint:      'Check 0x0D on i2cdetect -y 1',
      available: false,
    });
  }
  if (compassHeading === null) {
    return res.status(503).json({ error: 'No heading data yet', available: true });
  }
  res.json({
    heading:     compassHeading,
    cardinal:    toCardinal(compassHeading),
    chip:        'QMC5883L',
    calibrating: mag.calibrating,
    raw:         lastMagData?.raw ?? null,
    declination: MAGNETIC_DECLINATION,
    timestamp:   lastMagData?.timestamp ?? Date.now(),
    available:   true,
  });
});

app.get('/api/compass', (req, res) => {
  if (!mag.available) {
    return res.status(503).json({
      error: 'QMC5883L not available',
      hint:  'Confirmed chip is at 0x0D. Run: i2cdetect -y 1',
    });
  }
  if (!lastMagData) return res.status(503).json({ error: 'No compass data yet' });
  res.json({
    heading:     lastMagData.heading,
    cardinal:    toCardinal(lastMagData.heading),
    chip:        'QMC5883L',
    calibrating: mag.calibrating,
    raw:         lastMagData.raw,
    declination: MAGNETIC_DECLINATION,
    timestamp:   lastMagData.timestamp,
  });
});

app.get('/api/position', (req, res) => {
  const gpsPos = gps.getPosition();

  if (gpsPos.fix && gpsPos.lat !== null) {
    return res.json({
      source:     'gps',
      lat:        gpsPos.lat,
      lon:        gpsPos.lon,
      altitude:   gpsPos.altitude,
      speed:      gpsPos.speed,
      heading:    gpsPos.heading ?? compassHeading,
      satellites: gpsPos.satellites,
      hdop:       gpsPos.hdop,
      timestamp:  gpsPos.timestamp,
    });
  }

  const drPos = dr.getPosition();
  if (drPos) {
    return res.json({
      ...drPos,
      heading:   compassHeading ?? drPos.heading,
      timestamp: Date.now(),
    });
  }

  res.status(503).json({
    error:   'No position available',
    hint:    'Connect GPS or POST /api/anchor { lat, lon }',
    imuOk:   imu.available,
    magOk:   mag.available,
    gpsOk:   gps.available,
  });
});

app.post('/api/route', async (req, res) => {
  const { from, to } = req.body;
  if (!from || !to || from.length < 2 || to.length < 2) {
    return res.status(400).json({ error: '{ from: [lat,lon], to: [lat,lon] }' });
  }
  try {
    res.json(await getRoute(from[0], from[1], to[0], to[1]));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/calibrate/imu', async (req, res) => {
  if (!imu.available) return res.status(503).json({ error: 'IMU not available' });
  await imu.calibrate(200);
  res.json({ ok: true, offsets: { accel: imu.accelOffset, gyro: imu.gyroOffset } });
});

app.post('/api/calibrate/mag/start', (req, res) => {
  if (!mag.available) return res.status(503).json({ error: 'Magnetometer not available' });
  mag.startCalibration();
  res.json({ ok: true, message: 'Rotate device slowly in all directions, then POST /api/calibrate/mag/stop' });
});

app.post('/api/calibrate/mag/stop', (req, res) => {
  if (!mag.available) return res.status(503).json({ error: 'Magnetometer not available' });
  const result = mag.stopCalibration();
  res.json({ ok: true, ...result });
});

app.post('/api/anchor', (req, res) => {
  const { lat, lon, heading } = req.body;
  if (lat === undefined || lon === undefined) {
    return res.status(400).json({ error: '{ lat, lon }' });
  }
  const h = heading !== undefined ? parseFloat(heading) : (compassHeading ?? 0);
  dr.anchor(parseFloat(lat), parseFloat(lon), h);
  res.json({ ok: true, anchor: { lat, lon, heading: h } });
});

// ──────────────────────────────────────────────────────
// Boot
// ──────────────────────────────────────────────────────

initHardware().then(() => {
  imuLoop();
  magLoop();
  fusionLoop();
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] Doomsday Nav backend on :${PORT}`);
  });
});

process.on('SIGTERM', async () => {
  await imu.close(); mag.close(); gps.close(); process.exit(0);
});

// ── Helpers ───────────────────────────────────────────────────────
function toCardinal(deg) {
  const dirs = ['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW'];
  return dirs[Math.round(deg / 22.5) % 16];
}
