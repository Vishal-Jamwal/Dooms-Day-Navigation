/**
 * MPU-9250 I2C Driver for Pi Zero 2W
 *
 * The MPU-9250 is register-compatible with the MPU-6050 for accel/gyro.
 * Key differences vs MPU-6050:
 *   - WHO_AM_I register (0x75) returns 0x71 (not 0x68)
 *   - Has an internal AK8963 magnetometer on an auxiliary I2C bus
 *     (accessed via pass-through mode at address 0x0C)
 *   - Accel/gyro register map is IDENTICAL to MPU-6050
 *
 * Note: "MPU-9050" is not a real part number. If that's printed on your
 * breakout board it is almost certainly an MPU-9250 (or MPU-6500 variant).
 * This driver accepts WHO_AM_I values 0x71 (MPU-9250), 0x70 (MPU-9255),
 * and 0x68 (MPU-6050/6500 fallback) so it works with all of them.
 *
 * Wiring (Pi Zero 2W):
 *   VCC → 3.3V (Pin 1)
 *   GND → GND  (Pin 6)
 *   SDA → GPIO2 (Pin 3)
 *   SCL → GPIO3 (Pin 5)
 *   AD0 → GND   → I2C address 0x68
 *   AD0 → 3.3V  → I2C address 0x69
 */

const i2c = require('i2c-bus');

// ── Register map ─────────────────────────────────────────────────
const MPU9250_ADDR      = 0x68;
const WHO_AM_I          = 0x75;
const PWR_MGMT_1        = 0x6B;
const PWR_MGMT_2        = 0x6C;
const ACCEL_CONFIG      = 0x1C;  // ±2/4/8/16 g
const ACCEL_CONFIG2     = 0x1D;  // DLPF
const GYRO_CONFIG       = 0x1B;  // ±250/500/1000/2000 °/s
const CONFIG            = 0x1A;  // DLPF config
const INT_PIN_CFG       = 0x37;  // enable I2C pass-through for AK8963
const ACCEL_XOUT_H      = 0x3B;  // start of 14-byte burst

// ── Sensitivity at default full-scale range ───────────────────────
const ACCEL_SENS        = 16384.0;  // LSB/g   at ±2g
const GYRO_SENS         = 131.0;    // LSB/°/s at ±250°/s

// ── WHO_AM_I expected values ──────────────────────────────────────
const VALID_WHO_AM_I    = new Set([0x71, 0x70, 0x73, 0x68, 0x19]);

class MPU9250 {
  constructor(busNumber = 1, address = MPU9250_ADDR) {
    this.busNumber = busNumber;
    this.address   = address;
    this.bus       = null;
    this.available = false;
    this.whoAmI    = null;

    // Calibration offsets
    this.accelOffset = { x: 0, y: 0, z: 0 };
    this.gyroOffset  = { x: 0, y: 0, z: 0 };

    // Complementary filter state
    this.pitch    = 0;
    this.roll     = 0;
    this.yaw      = 0;
    this.lastTime = null;
    this.ALPHA    = 0.98;
  }

  async init() {
    try {
      this.bus = await i2c.openPromisified(this.busNumber);

      // Verify device identity
      const whoAmI = await this.bus.readByte(this.address, WHO_AM_I);
      this.whoAmI  = whoAmI;

      if (!VALID_WHO_AM_I.has(whoAmI)) {
        console.warn(`[MPU9250] Unexpected WHO_AM_I: 0x${whoAmI.toString(16)} — proceeding anyway`);
      } else {
        console.log(`[MPU9250] WHO_AM_I=0x${whoAmI.toString(16)} ✓`);
      }

      // Wake device, use best available clock source (PLL with gyro X)
      await this.bus.writeByte(this.address, PWR_MGMT_1, 0x01);
      await delay(100);

      // Enable all sensors
      await this.bus.writeByte(this.address, PWR_MGMT_2, 0x00);

      // ±2g accelerometer
      await this.bus.writeByte(this.address, ACCEL_CONFIG, 0x00);
      // Accel DLPF: 41 Hz bandwidth (reduces noise)
      await this.bus.writeByte(this.address, ACCEL_CONFIG2, 0x03);

      // ±250°/s gyroscope
      await this.bus.writeByte(this.address, GYRO_CONFIG, 0x00);
      // Gyro DLPF: 41 Hz
      await this.bus.writeByte(this.address, CONFIG, 0x03);

      // Enable I2C pass-through so the AK8963 magnetometer is directly
      // accessible on the main I2C bus (needed by hmc5883l.js or ak8963.js)
      await this.bus.writeByte(this.address, INT_PIN_CFG, 0x02);
      await delay(10);

      this.available = true;
      console.log(`[MPU9250] Initialised on bus ${this.busNumber}, addr 0x${this.address.toString(16)}`);
      return true;
    } catch (err) {
      console.warn(`[MPU9250] Init failed: ${err.message}`);
      this.available = false;
      return false;
    }
  }

  /**
   * Burst-read 14 bytes starting at ACCEL_XOUT_H.
   * Layout: AX(2) AY(2) AZ(2) TEMP(2) GX(2) GY(2) GZ(2)
   */
  async readRaw() {
    if (!this.available) return null;
    try {
      const buf = Buffer.alloc(14);
      await this.bus.readI2cBlock(this.address, ACCEL_XOUT_H, 14, buf);

      const ax_raw   = buf.readInt16BE(0);
      const ay_raw   = buf.readInt16BE(2);
      const az_raw   = buf.readInt16BE(4);
      const temp_raw = buf.readInt16BE(6);
      const gx_raw   = buf.readInt16BE(8);
      const gy_raw   = buf.readInt16BE(10);
      const gz_raw   = buf.readInt16BE(12);

      return {
        accel: {
          x: (ax_raw / ACCEL_SENS) - this.accelOffset.x,
          y: (ay_raw / ACCEL_SENS) - this.accelOffset.y,
          z: (az_raw / ACCEL_SENS) - this.accelOffset.z,
        },
        gyro: {
          x: (gx_raw / GYRO_SENS) - this.gyroOffset.x,
          y: (gy_raw / GYRO_SENS) - this.gyroOffset.y,
          z: (gz_raw / GYRO_SENS) - this.gyroOffset.z,
        },
        // MPU-9250 temp formula (from datasheet §3.4.2)
        temp: ((temp_raw - 0) / 333.87) + 21.0,
        timestamp: Date.now(),
      };
    } catch (err) {
      console.error(`[MPU9250] Read error: ${err.message}`);
      return null;
    }
  }

  /**
   * Complementary filter: fuses accel + gyro into pitch/roll.
   * Pass compassHeading (degrees, 0=North) to anchor yaw.
   * Without a compass the yaw drifts over time.
   */
  async getOrientation(compassHeading = null) {
    const raw = await this.readRaw();
    if (!raw) return null;

    const now = Date.now();
    if (!this.lastTime) { this.lastTime = now; return { pitch: 0, roll: 0, yaw: compassHeading || 0, raw }; }

    const dt = Math.min((now - this.lastTime) / 1000, 0.1); // cap dt at 100ms
    this.lastTime = now;

    const { accel, gyro } = raw;

    // Accel-derived tilt angles (radians → degrees)
    const accelPitch = Math.atan2(accel.y, Math.sqrt(accel.x ** 2 + accel.z ** 2)) * (180 / Math.PI);
    const accelRoll  = Math.atan2(-accel.x, accel.z) * (180 / Math.PI);

    // Complementary filter: trust gyro short-term, accel long-term
    this.pitch = this.ALPHA * (this.pitch + gyro.x * dt) + (1 - this.ALPHA) * accelPitch;
    this.roll  = this.ALPHA * (this.roll  + gyro.y * dt) + (1 - this.ALPHA) * accelRoll;

    // Yaw: use compass if available (no drift), else integrate gyro (drifts)
    if (compassHeading !== null) {
      this.yaw = compassHeading;
    } else {
      this.yaw = ((this.yaw + gyro.z * dt) + 360) % 360;
    }

    return {
      pitch: this.pitch,
      roll:  this.roll,
      yaw:   this.yaw,
      raw,
    };
  }

  /**
   * Collect N samples at rest to zero out offsets.
   * Keep device flat and still during calibration.
   */
  async calibrate(samples = 200) {
    if (!this.available) return;
    console.log(`[MPU9250] Calibrating (${samples} samples) — keep still...`);

    let ax = 0, ay = 0, az = 0, gx = 0, gy = 0, gz = 0;
    let count = 0;

    for (let i = 0; i < samples; i++) {
      const r = await this.readRaw();
      if (!r) continue;
      ax += r.accel.x; ay += r.accel.y; az += r.accel.z;
      gx += r.gyro.x;  gy += r.gyro.y;  gz += r.gyro.z;
      count++;
      await delay(10);
    }

    if (count === 0) { console.warn('[MPU9250] Calibration got no samples'); return; }

    // Accel: Z should read 1g when flat; X and Y should be 0
    this.accelOffset = {
      x: ax / count,
      y: ay / count,
      z: (az / count) - 1.0,
    };
    this.gyroOffset = {
      x: gx / count,
      y: gy / count,
      z: gz / count,
    };
    this.yaw = 0;

    console.log('[MPU9250] Calibration done →', {
      accel: obj3(this.accelOffset),
      gyro:  obj3(this.gyroOffset),
    });
  }

  async close() {
    if (this.bus) await this.bus.close();
  }
}

// ── Helpers ───────────────────────────────────────────────────────
function delay(ms) { return new Promise(r => setTimeout(r, ms)); }
function obj3(o) {
  return { x: o.x.toFixed(4), y: o.y.toFixed(4), z: o.z.toFixed(4) };
}

module.exports = MPU9250;
