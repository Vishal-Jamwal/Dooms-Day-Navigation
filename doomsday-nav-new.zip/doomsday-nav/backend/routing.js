/**
 * Routing Module
 *
 * Uses the free OSRM demo server (router.project-osrm.org) for routing.
 * Falls back to a straight-line "crow flies" route if offline.
 *
 * Rate limit: OSRM demo is for development only.
 * For production, set OSRM_HOST env var to your own OSRM instance.
 */

const axios = require('axios');

const OSRM_BASE = process.env.OSRM_HOST
  ? `http://${process.env.OSRM_HOST}:${process.env.OSRM_PORT || 5000}`
  : 'https://router.project-osrm.org';

const TIMEOUT_MS = 8000;

/**
 * Get a driving route between two coordinates.
 * Returns GeoJSON LineString + turn-by-turn steps.
 *
 * @param {number} fromLat
 * @param {number} fromLon
 * @param {number} toLat
 * @param {number} toLon
 * @returns {object} { distance, duration, steps, geometry, source }
 */
async function getRoute(fromLat, fromLon, toLat, toLon) {
  const coords = `${fromLon},${fromLat};${toLon},${toLat}`;
  const url = `${OSRM_BASE}/route/v1/driving/${coords}`;

  try {
    const resp = await axios.get(url, {
      params: {
        overview:     'full',
        geometries:   'geojson',
        steps:        true,
        annotations:  false,
      },
      timeout: TIMEOUT_MS,
    });

    if (resp.data.code !== 'Ok' || !resp.data.routes.length) {
      throw new Error('No route found');
    }

    const route = resp.data.routes[0];
    const steps = _parseSteps(route.legs[0].steps);

    return {
      source:   'osrm',
      distance: route.distance,    // metres
      duration: route.duration,    // seconds
      geometry: route.geometry,    // GeoJSON LineString
      steps,
    };
  } catch (err) {
    console.warn(`[Routing] OSRM failed (${err.message}), using straight-line fallback`);
    return _straightLineFallback(fromLat, fromLon, toLat, toLon);
  }
}

/** Parse OSRM step objects into a simpler format */
function _parseSteps(osrmSteps) {
  return osrmSteps
    .filter(s => s.maneuver.type !== 'depart' || s.name)
    .map(s => ({
      instruction: _buildInstruction(s),
      distance:    Math.round(s.distance),
      duration:    Math.round(s.duration),
      type:        s.maneuver.type,
      modifier:    s.maneuver.modifier,
      location:    s.maneuver.location,  // [lon, lat]
      name:        s.name || '',
    }));
}

function _buildInstruction(step) {
  const mod  = step.maneuver.modifier;
  const type = step.maneuver.type;
  const name = step.name ? ` onto ${step.name}` : '';

  const turns = {
    'turn left':        `Turn left${name}`,
    'turn right':       `Turn right${name}`,
    'turn slight left': `Bear left${name}`,
    'turn slight right':`Bear right${name}`,
    'turn sharp left':  `Sharp left${name}`,
    'turn sharp right': `Sharp right${name}`,
    'continue':         `Continue straight${name}`,
    'merge':            `Merge${name}`,
    'roundabout':       `Enter roundabout${name}`,
    'arrive':           'Arrive at destination',
    'depart':           `Head ${mod || 'forward'}${name}`,
  };

  const key = mod ? `${type} ${mod}` : type;
  return turns[key] || turns[type] || `${type}${name}`;
}

/**
 * Straight-line fallback when OSRM is unreachable.
 * Generates a single-step "go direct" route.
 */
function _straightLineFallback(fromLat, fromLon, toLat, toLon) {
  const dist = _haversine(fromLat, fromLon, toLat, toLon);
  const bearing = _bearing(fromLat, fromLon, toLat, toLon);
  const dirs = ['N','NE','E','SE','S','SW','W','NW'];
  const dir  = dirs[Math.round(bearing / 45) % 8];

  return {
    source:   'fallback_direct',
    distance: dist,
    duration: dist / 1.4,  // assume 1.4 m/s walking
    geometry: {
      type: 'LineString',
      coordinates: [[fromLon, fromLat], [toLon, toLat]],
    },
    steps: [
      {
        instruction: `Head ${dir} for ${_formatDist(dist)}`,
        distance:    dist,
        duration:    dist / 1.4,
        type:        'depart',
        location:    [fromLon, fromLat],
        name:        '',
      },
      {
        instruction: 'Arrive at destination',
        distance:    0,
        duration:    0,
        type:        'arrive',
        location:    [toLon, toLat],
        name:        '',
      },
    ],
  };
}

function _haversine(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;
  const a  = Math.sin(Δφ/2)**2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

function _bearing(lat1, lon1, lat2, lon2) {
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}

function _formatDist(m) {
  return m >= 1000 ? `${(m/1000).toFixed(1)} km` : `${Math.round(m)} m`;
}

module.exports = { getRoute };
