/**
 * GPS NMEA Parser
 * Reads GPRMC / GPGGA sentences from a serial USB GPS dongle.
 * Falls back gracefully if no GPS is connected.
 *
 * Common GPS module paths on Pi:
 *   /dev/ttyUSB0  (USB dongle)
 *   /dev/ttyAMA0  (UART GPIO)
 *   /dev/ttyS0    (mini UART)
 */

const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');

class GPSParser {
  constructor(portPath = '/dev/ttyUSB0', baudRate = 9600) {
    this.portPath  = portPath;
    this.baudRate  = baudRate;
    this.available = false;
    this.fix       = false;

    this.position = {
      lat:       null,
      lon:       null,
      altitude:  null,
      speed:     null,   // knots
      heading:   null,   // degrees true
      satellites: 0,
      hdop:      null,
      timestamp: null,
    };
  }

  async init() {
    try {
      this.port = new SerialPort({ path: this.portPath, baudRate: this.baudRate });
      const parser = this.port.pipe(new ReadlineParser({ delimiter: '\r\n' }));

      parser.on('data', (line) => this._parseLine(line.trim()));

      this.port.on('error', (err) => {
        console.warn(`[GPS] Serial error: ${err.message}`);
        this.available = false;
      });

      this.available = true;
      console.log(`[GPS] Listening on ${this.portPath} @ ${this.baudRate} baud`);
      return true;
    } catch (err) {
      console.warn(`[GPS] Not available: ${err.message}`);
      this.available = false;
      return false;
    }
  }

  _parseLine(line) {
    if (!line.startsWith('$')) return;
    if (!this._checksum(line)) return;

    const parts = line.split(',');
    const type  = parts[0].replace('$', '');

    if (type === 'GPRMC' || type === 'GNRMC') {
      this._parseRMC(parts);
    } else if (type === 'GPGGA' || type === 'GNGGA') {
      this._parseGGA(parts);
    }
  }

  /** GPRMC: Recommended Minimum — lat, lon, speed, heading, date */
  _parseRMC(p) {
    // p[2] = A (active) or V (void)
    this.fix = p[2] === 'A';
    if (!this.fix) return;

    this.position.lat     = this._ddmm(p[3], p[4]);
    this.position.lon     = this._ddmm(p[5], p[6]);
    this.position.speed   = parseFloat(p[7]) || 0;
    this.position.heading = parseFloat(p[8]) || 0;
    this.position.timestamp = Date.now();
  }

  /** GPGGA: Fix data — altitude, satellites, HDOP */
  _parseGGA(p) {
    if (parseInt(p[6]) === 0) return; // no fix
    this.position.lat       = this._ddmm(p[2], p[3]);
    this.position.lon       = this._ddmm(p[4], p[5]);
    this.position.altitude  = parseFloat(p[9]) || null;
    this.position.satellites = parseInt(p[7]) || 0;
    this.position.hdop      = parseFloat(p[8]) || null;
    this.position.timestamp = Date.now();
  }

  /** Convert DDMM.MMMM to decimal degrees */
  _ddmm(raw, dir) {
    if (!raw) return null;
    const dot  = raw.indexOf('.');
    const deg  = parseFloat(raw.substring(0, dot - 2));
    const min  = parseFloat(raw.substring(dot - 2));
    let dd     = deg + min / 60;
    if (dir === 'S' || dir === 'W') dd = -dd;
    return dd;
  }

  /** Validate NMEA checksum (*XX at end of sentence) */
  _checksum(sentence) {
    const star = sentence.lastIndexOf('*');
    if (star === -1) return true; // no checksum, accept
    const expected = parseInt(sentence.substring(star + 1), 16);
    let xor = 0;
    for (let i = 1; i < star; i++) xor ^= sentence.charCodeAt(i);
    return xor === expected;
  }

  getPosition() {
    return { ...this.position, fix: this.fix, available: this.available };
  }

  close() {
    if (this.port && this.port.isOpen) this.port.close();
  }
}

module.exports = GPSParser;
