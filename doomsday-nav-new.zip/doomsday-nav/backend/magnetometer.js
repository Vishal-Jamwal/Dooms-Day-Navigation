/**
 * QMC5883L Magnetometer Driver
 * I2C address: 0x0D
 *
 * This is the chip confirmed working on your board. The driver is written
 * specifically for QMC5883L — no HMC5883L code path, no auto-detection
 * ambiguity, no silent failures. If 0x0D isn't on the bus, it says so clearly.
 *
 * Register map (QMC5883L datasheet):
 *   0x00–0x05  Data output (X_LSB, X_MSB, Y_LSB, Y_MSB, Z_LSB, Z_MSB)
 *   0x06       Status register (bit 0 = DRDY data ready)
 *   0x09       Control register 1 — mode/ODR/RNG/OSR
 *   0x0A       Control register 2 — soft reset / standby
 *   0x0B       SET/RESET period register — must be 0x01
 *   0x0D       Chip ID — reads 0xFF on genuine QMC5883L
 *
 * Control register 1 (0x09) value 0x1D breakdown:
 *   Bits [1:0] = 01  → Continuous mode
 *   Bits [3:2] = 11  → 200Hz ODR
 *   Bits [5:4] = 00  → ±2 Gauss range
 *   Bits [7:6] = 00  → 64 OSR (oversampling ratio)
 *   → 0b00000001 | 0b00001100 | 0b00000000 | 0b00000000 = 0x0D
 *   Wait — your working value is 0x1D = 0b00011101:
 *   Bits [1:0] = 01  → Continuous
 *   Bits [3:2] = 11  → 200Hz ODR
 *   Bits [5:4] = 01  → ±8 Gauss range (wider, less likely to saturate indoors)
 *   Bits [7:6] = 00  → 64 OSR
 *   This is the value that works on your board — kept exactly as-is.
 *
 * Smoothing: exponential moving average (EMA), alpha configurable.
 * Calibration: hard-iron offset via min/max collection, soft-iron scale normalisation.
 */

const i2c = require('i2c-bus');

const QMC_ADDR         = 0x0D;
const REG_DATA         = 0x00;  // 6 bytes: XLSB XMSB YLSB YMSB ZLSB ZMSB
const REG_STATUS       = 0x06;  // bit0=DRDY
const REG_CONTROL1     = 0x09;  // mode/ODR/RNG/OSR
const REG_CONTROL2     = 0x0A;  // soft reset
const REG_PERIOD       = 0x0B;  // must write 0x01
const REG_CHIP_ID      = 0x0D;  // 0xFF on genuine chip

// Your confirmed working config value
const CONTROL1_VALUE   = 0x1D;  // continuous, 200Hz, ±8Ga, 64xOSR

function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

class QMC5883L {
  /**
   * @param {number} busNumber     I2C bus number (1 on Pi)
   * @param {object} options
   * @param {number} options.smoothingAlpha  EMA alpha 0–1 (lower = smoother, more lag). Default 0.2
   * @param {number} options.declination     Magnetic declination degrees for your location
   *                                         Mumbai ≈ -0.8, Delhi ≈ 0.5, Bangalore ≈ -0.7
   *                                         Find: https://ngdc.noaa.gov/geomag/calculators/magcalc.shtml
   */
  constructor(busNumber = 1, { smoothingAlpha = 0.2, declination = 0 } = {}) {
    this.busNumber = busNumber;
    this.bus       = null;
    this.available = false;

    this.smoothingAlpha = smoothingAlpha;
    this.declination    = declination;

    // Smoothed heading value (EMA output)
    this._smoothedHeading = null;

    // Hard-iron calibration offsets (raw ADC units)
    this.offset = { x: 0, y: 0, z: 0 };

    // Soft-iron scale factors (normalised so all axes have equal range)
    this.scale  = { x: 1, y: 1, z: 1 };

    // Calibration collection state
    this._calMin      = null;
    this._calMax      = null;
    this._calInterval = null;
    this.calibrating  = false;
  }

  // ─────────────────────────────────────────────────────────────────
  // Init & probe
  // ─────────────────────────────────────────────────────────────────

  async init() {
    try {
      this.bus = await i2c.openPromisified(this.busNumber);
    } catch (err) {
      console.error(`[QMC5883L] Cannot open I2C bus ${this.busNumber}: ${err.message}`);
      return false;
    }

    // Verify device is present and responding
    const found = await this._probe();
    if (!found) {
      console.error('[QMC5883L] Device not found at 0x0D');
      console.error('[QMC5883L] Run: i2cdetect -y 1   — should show 0d');
      return false;
    }

    // Configure chip
    try {
      await this._configure();
    } catch (err) {
      console.error(`[QMC5883L] Configuration failed: ${err.message}`);
      return false;
    }

    this.available = true;
    console.log('[QMC5883L] Ready at 0x0D ✓');
    return true;
  }

  async _probe() {
    // Try chip ID register first (fast path)
    try {
      const id = await this.bus.readByte(QMC_ADDR, REG_CHIP_ID);
      if (id === 0xFF) return true;
    } catch { /* fall through to write probe */ }

    // Some boards return different ID values — try a write probe instead
    // If the device ACKs the write, it's there
    try {
      await this.bus.writeByte(QMC_ADDR, REG_CONTROL2, 0x80); // soft reset — safe to send
      await delay(20);
      return true;
    } catch {
      return false;
    }
  }

  async _configure() {
    // Soft reset first to clear any previous state
    await this.bus.writeByte(QMC_ADDR, REG_CONTROL2, 0x80);
    await delay(20);

    // Mandatory: SET/RESET period register
    await this.bus.writeByte(QMC_ADDR, REG_PERIOD, 0x01);

    // Apply your confirmed working config: 0x1D
    await this.bus.writeByte(QMC_ADDR, REG_CONTROL1, CONTROL1_VALUE);

    // Wait for first sample
    await delay(10);
  }

  // ─────────────────────────────────────────────────────────────────
  // Reading
  // ─────────────────────────────────────────────────────────────────

  /**
   * Read raw X/Y/Z ADC values from the chip.
   * Returns null on I2C error.
   */
  async readRaw() {
    if (!this.available) return null;
    try {
      const buf = Buffer.alloc(6);
      await this.bus.readI2cBlock(QMC_ADDR, REG_DATA, 6, buf);

      // QMC5883L is little-endian, order is X Y Z
      const xRaw = buf.readInt16LE(0);
      const yRaw = buf.readInt16LE(2);
      const zRaw = buf.readInt16LE(4);

      return { xRaw, yRaw, zRaw };
    } catch (err) {
      console.error(`[QMC5883L] Read error: ${err.message}`);
      return null;
    }
  }

  /**
   * Read calibrated X/Y/Z values (hard-iron + soft-iron corrected).
   */
  async readCalibrated() {
    const raw = await this.readRaw();
    if (!raw) return null;

    // Update calibration min/max if collecting
    if (this.calibrating) this._updateCalBounds(raw);

    return {
      x: (raw.xRaw - this.offset.x) * this.scale.x,
      y: (raw.yRaw - this.offset.y) * this.scale.y,
      z: (raw.zRaw - this.offset.z) * this.scale.z,
      raw,
    };
  }

  /**
   * Get smoothed compass heading in degrees (0 = North, clockwise).
   * Also returns the calibrated xyz so the caller doesn't need a second read.
   *
   * @param {number|null} pitchDeg  Pitch from IMU for tilt compensation (optional)
   * @param {number|null} rollDeg   Roll from IMU for tilt compensation (optional)
   * @returns {{ heading: number, cal: object }|null}  null on read failure
   */
  async getHeading(pitchDeg = null, rollDeg = null) {
    const cal = await this.readCalibrated();
    if (!cal) return null;

    let { x, y, z } = cal;

    // Tilt compensation — corrects heading when device is not held level
    // Requires pitch/roll from MPU-9250 complementary filter
    if (pitchDeg !== null && rollDeg !== null) {
      const pitch = pitchDeg * (Math.PI / 180);
      const roll  = rollDeg  * (Math.PI / 180);
      // Rotate magnetic vector to horizontal plane
      const xh = x * Math.cos(pitch) + z * Math.sin(pitch);
      const yh = x * Math.sin(roll) * Math.sin(pitch)
               + y * Math.cos(roll)
               - z * Math.sin(roll) * Math.cos(pitch);
      x = xh;
      y = yh;
    }

    // Heading: atan2 gives angle from East axis; we want from North
    let heading = Math.atan2(y, x) * (180 / Math.PI);

    // Apply local magnetic declination
    heading += this.declination;

    // Normalise to 0–360
    heading = ((heading % 360) + 360) % 360;

    // Exponential moving average smoothing
    // Handles wrap-around at 0°/360° boundary correctly
    if (this._smoothedHeading === null) {
      this._smoothedHeading = heading;
    } else {
      let diff = heading - this._smoothedHeading;
      // Wrap diff into [-180, 180] so we always take the short arc
      if (diff >  180) diff -= 360;
      if (diff < -180) diff += 360;
      this._smoothedHeading = ((this._smoothedHeading + this.smoothingAlpha * diff) + 360) % 360;
    }

    return { heading: this._smoothedHeading, cal };
  }

  // ─────────────────────────────────────────────────────────────────
  // Hard-iron + soft-iron calibration
  // ─────────────────────────────────────────────────────────────────

  /**
   * Begin collecting calibration samples.
   * After calling this, slowly rotate the device through all orientations
   * (figure-8 or full 360° spin). Then call stopCalibration().
   */
  startCalibration() {
    this._calMin = { x:  Infinity, y:  Infinity, z:  Infinity };
    this._calMax = { x: -Infinity, y: -Infinity, z: -Infinity };
    this.calibrating = true;
    console.log('[QMC5883L] Calibration started — rotate device in all directions');
  }

  _updateCalBounds({ xRaw, yRaw, zRaw }) {
    if (!this._calMin) return;
    if (xRaw < this._calMin.x) this._calMin.x = xRaw;
    if (yRaw < this._calMin.y) this._calMin.y = yRaw;
    if (zRaw < this._calMin.z) this._calMin.z = zRaw;
    if (xRaw > this._calMax.x) this._calMax.x = xRaw;
    if (yRaw > this._calMax.y) this._calMax.y = yRaw;
    if (zRaw > this._calMax.z) this._calMax.z = zRaw;
  }

  /**
   * Stop collecting and compute offsets + scale factors.
   * @returns {{ offset, scale }} Applied calibration values
   */
  stopCalibration() {
    this.calibrating = false;

    if (!this._calMin || !this._calMax) {
      console.warn('[QMC5883L] No calibration data collected');
      return { offset: this.offset, scale: this.scale };
    }

    // Hard-iron offset = midpoint of observed range per axis
    this.offset = {
      x: (this._calMin.x + this._calMax.x) / 2,
      y: (this._calMin.y + this._calMax.y) / 2,
      z: (this._calMin.z + this._calMax.z) / 2,
    };

    // Soft-iron: equalise axis ranges (compensates for different axis sensitivities)
    const ranges = {
      x: (this._calMax.x - this._calMin.x) / 2,
      y: (this._calMax.y - this._calMin.y) / 2,
      z: (this._calMax.z - this._calMin.z) / 2,
    };
    const avgRange = (ranges.x + ranges.y + ranges.z) / 3;
    if (avgRange > 0) {
      this.scale = {
        x: avgRange / (ranges.x || 1),
        y: avgRange / (ranges.y || 1),
        z: avgRange / (ranges.z || 1),
      };
    }

    // Reset smoothed heading so it picks up fresh calibrated value
    this._smoothedHeading = null;

    console.log('[QMC5883L] Calibration complete:', {
      offset: fmt3(this.offset),
      scale:  fmt3s(this.scale),
    });

    return { offset: this.offset, scale: this.scale };
  }

  /**
   * Load previously saved calibration (e.g. from a config file or env vars).
   */
  loadCalibration(offset, scale) {
    if (offset) this.offset = offset;
    if (scale)  this.scale  = scale;
    this._smoothedHeading = null;
    console.log('[QMC5883L] Calibration loaded');
  }

  // ─────────────────────────────────────────────────────────────────
  // Cleanup
  // ─────────────────────────────────────────────────────────────────

  close() {
    this.calibrating = false;
    // Don't close the bus here if it was shared — let the caller manage it
  }
}

function fmt3(o)  { return { x: o.x.toFixed(1), y: o.y.toFixed(1), z: o.z.toFixed(1) }; }
function fmt3s(o) { return { x: o.x.toFixed(3), y: o.y.toFixed(3), z: o.z.toFixed(3) }; }

module.exports = QMC5883L;
