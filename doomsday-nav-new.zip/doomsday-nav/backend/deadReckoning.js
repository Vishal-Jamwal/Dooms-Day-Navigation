/**
 * Dead Reckoning Position Estimator
 *
 * When GPS is unavailable, estimates position using:
 *   - MPU6050 accelerometer (velocity via integration)
 *   - MPU6050 gyroscope (heading via integration)
 *   - Last known GPS position as origin
 *
 * Accuracy degrades over time due to drift — this is a fallback only.
 * Re-anchors automatically when GPS fix returns.
 */

class DeadReckoning {
  constructor() {
    this.enabled = false;
    this.origin  = null;   // last known GPS fix {lat, lon}

    // Velocity in m/s (world frame)
    this.vx = 0;
    this.vy = 0;

    // Position offset from origin in meters
    this.dx = 0;
    this.dy = 0;

    // Current heading in degrees (0 = North)
    this.heading = 0;

    this.lastUpdate = null;
    this.ACCEL_THRESHOLD = 0.05;  // g — ignore tiny noise
    this.VELOCITY_DECAY  = 0.95;  // damping per cycle to prevent runaway
  }

  /**
   * Anchor to a known GPS position.
   * Call this whenever GPS fix is available.
   */
  anchor(lat, lon, headingDeg) {
    this.origin  = { lat, lon };
    this.dx = 0;
    this.dy = 0;
    this.vx = 0;
    this.vy = 0;
    if (headingDeg !== undefined) this.heading = headingDeg;
    this.lastUpdate = Date.now();
    this.enabled = true;
  }

  /**
   * Update dead reckoning with new IMU data.
   * @param {object} orientation      - from MPU9250.getOrientation()
   * @param {number} gpsHeading       - from GPS NMEA (overrides all)
   * @param {number} compassHeading   - from HMC5883L (overrides gyro, used when no GPS)
   */
  update(orientation, gpsHeading, compassHeading) {
    if (!this.enabled || !this.origin) return;

    const now = Date.now();
    if (!this.lastUpdate) { this.lastUpdate = now; return; }

    const dt = (now - this.lastUpdate) / 1000; // seconds
    this.lastUpdate = now;

    // Heading priority: GPS > Compass > Gyro integration
    if (gpsHeading !== null && gpsHeading !== undefined) {
      this.heading = gpsHeading;
    } else if (compassHeading !== null && compassHeading !== undefined) {
      // Low-pass blend compass into current heading to suppress magnetic noise
      this.heading = 0.85 * this.heading + 0.15 * compassHeading;
      this.heading = ((this.heading) + 360) % 360;
    } else if (orientation) {
      this.heading = ((this.heading + orientation.raw.gyro.z * dt) + 360) % 360;
    }

    // Get forward acceleration (device X axis projected to world frame)
    if (orientation) {
      const { accel } = orientation.raw;
      const headingRad = this.heading * (Math.PI / 180);

      // Filter small accelerations (noise floor)
      const ax = Math.abs(accel.x) > this.ACCEL_THRESHOLD ? accel.x * 9.81 : 0;
      const ay = Math.abs(accel.y) > this.ACCEL_THRESHOLD ? accel.y * 9.81 : 0;

      // Project device acceleration to world North/East
      const worldAx = ax * Math.cos(headingRad) - ay * Math.sin(headingRad);
      const worldAy = ax * Math.sin(headingRad) + ay * Math.cos(headingRad);

      // Integrate acceleration → velocity
      this.vx = (this.vx + worldAx * dt) * this.VELOCITY_DECAY;
      this.vy = (this.vy + worldAy * dt) * this.VELOCITY_DECAY;

      // Integrate velocity → position (meters)
      this.dx += this.vx * dt;
      this.dy += this.vy * dt;
    }
  }

  /**
   * Convert meter offset to lat/lon delta and add to origin.
   */
  getPosition() {
    if (!this.origin) return null;

    // 1 degree latitude ≈ 111,320 meters
    // 1 degree longitude ≈ 111,320 * cos(lat) meters
    const latOffset = this.dy / 111320;
    const lonOffset = this.dx / (111320 * Math.cos(this.origin.lat * Math.PI / 180));

    return {
      lat:     this.origin.lat + latOffset,
      lon:     this.origin.lon + lonOffset,
      heading: this.heading,
      speed:   Math.sqrt(this.vx ** 2 + this.vy ** 2),
      source:  'dead_reckoning',
      driftMeters: Math.sqrt(this.dx ** 2 + this.dy ** 2),
    };
  }

  reset() {
    this.enabled = false;
    this.origin  = null;
    this.dx = this.dy = this.vx = this.vy = 0;
  }
}

module.exports = DeadReckoning;
