#!/bin/bash
# ────────────────────────────────────────────────────────────────
#  Doomsday Navigation — Pi Zero 2W Setup Script
#  Run as root: sudo ./scripts/setup.sh
# ────────────────────────────────────────────────────────────────
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
USER_HOME=$(eval echo ~${SUDO_USER:-pi})
SERVICE_USER=${SUDO_USER:-pi}

RED='\033[0;31m'; GRN='\033[0;32m'; YEL='\033[1;33m'; NC='\033[0m'
log()  { echo -e "${GRN}[setup]${NC} $1"; }
warn() { echo -e "${YEL}[warn] ${NC} $1"; }
err()  { echo -e "${RED}[error]${NC} $1"; exit 1; }

[[ $EUID -ne 0 ]] && err "Run as root: sudo $0"

log "Updating package lists..."
apt-get update -qq

# ── Node.js ──────────────────────────────────────────────────────
if ! command -v node &>/dev/null || [[ $(node --version | cut -d. -f1 | tr -d 'v') -lt 18 ]]; then
  log "Installing Node.js 20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
else
  log "Node.js $(node --version) already installed"
fi

# ── I2C tools ────────────────────────────────────────────────────
log "Installing I2C tools..."
apt-get install -y -qq i2c-tools

# Enable I2C interface
if ! grep -q "^dtparam=i2c_arm=on" /boot/config.txt 2>/dev/null && \
   ! grep -q "^dtparam=i2c_arm=on" /boot/firmware/config.txt 2>/dev/null; then
  warn "Enabling I2C in /boot/firmware/config.txt — reboot required after setup"
  CONFIG=/boot/firmware/config.txt
  [[ -f /boot/config.txt ]] && CONFIG=/boot/config.txt
  echo "dtparam=i2c_arm=on" >> "$CONFIG"
  echo "dtoverlay=i2c-rtc,ds1307" >> "$CONFIG"
fi

# Add user to i2c group
usermod -aG i2c "$SERVICE_USER" 2>/dev/null || true

# ── Backend deps ─────────────────────────────────────────────────
log "Installing backend dependencies..."
cd "$SCRIPT_DIR/backend"
sudo -u "$SERVICE_USER" npm install --omit=dev

# ── Frontend deps + build ─────────────────────────────────────────
log "Installing frontend dependencies..."
cd "$SCRIPT_DIR/frontend"
sudo -u "$SERVICE_USER" npm install

log "Building frontend for production..."
sudo -u "$SERVICE_USER" npm run build

# ── Systemd services ──────────────────────────────────────────────
log "Installing systemd services..."

sed "s|__DIR__|$SCRIPT_DIR|g; s|__USER__|$SERVICE_USER|g" \
  "$SCRIPT_DIR/systemd/doomsday-backend.service" \
  > /etc/systemd/system/doomsday-backend.service

sed "s|__DIR__|$SCRIPT_DIR|g; s|__USER__|$SERVICE_USER|g" \
  "$SCRIPT_DIR/systemd/doomsday-frontend.service" \
  > /etc/systemd/system/doomsday-frontend.service

systemctl daemon-reload
systemctl enable doomsday-backend doomsday-frontend

# ── Finish ───────────────────────────────────────────────────────
PI_IP=$(hostname -I | awk '{print $1}')

echo ""
echo -e "${GRN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GRN}║      Doomsday Nav — Setup Complete       ║${NC}"
echo -e "${GRN}╚══════════════════════════════════════════╝${NC}"
echo ""
echo "  Backend service:  doomsday-backend"
echo "  Frontend service: doomsday-frontend"
echo ""
echo "  Start now:"
echo "    sudo systemctl start doomsday-backend"
echo "    sudo systemctl start doomsday-frontend"
echo ""
echo "  Then open: http://${PI_IP}:5173"
echo ""
warn "If I2C was just enabled, reboot first: sudo reboot"
echo ""
log "Wire MPU6050:"
echo "    VCC → Pin 1  (3.3V)"
echo "    GND → Pin 6  (GND)"
echo "    SDA → Pin 3  (GPIO2)"
echo "    SCL → Pin 5  (GPIO3)"
echo ""
log "Verify with: i2cdetect -y 1   (should show 0x68)"
